## Session 7

#### In this assignment we have explored different first class functions as reduce partial and also we have used list comprehension in great depth. Below are the functions we have used to solve some problems as discussed below:

#### fibonacci_check:

##### This function This function checks for a given number n if its fibonacci or not and returns an output i.e. fibonacci or not a fibonacci no



#### even_odd_summation:

##### This function takes two lists as input and adds even no for the first list and odd number the second list and returns summation result as a list.



#### vowel_stripping:

##### This function takes a string as an input strips out vowels and returns stripted out string.



#### relu:

##### This function takes a list as an input and acts as Relu i.e. when an element is -ve it returns 0 else the element.



#### sigmoid:

##### This function takes a list as an input and acts as sigmoid function and returns a list of sigmoid output.



#### char_shift:

##### This function takes a string as an input and shifts each character by 5 and returns shifted string.



#### swear_word_check:

##### This function takes and input of a paragraph and check if swear word is present in the paragraph and returns a list of swear words that is present.



#### even_add_reduce:

##### This function takes an input as a list and gives output as a summation of even no in the list using reduce.



#### biggest_char:

##### This function takes an input as a string and returns the biggest output character in the string.



#### no_add_3rd:

##### This function takes a list as an input and returns summation of every 3ed element.



#### random_numberplate_generator:

##### This function generates a list 15 random numberplate.



#### plate_partial:

##### This partial function takes the above function and we can only pass state information as start and end range of last 4 digit is already hardcoded