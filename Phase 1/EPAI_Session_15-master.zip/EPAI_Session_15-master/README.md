## Generator

#### In this assignment we have implemented a csv reader which can read a csv of parking ticket violations for NYC. Fot that we have created one main function that is read_csv that can read and yield the data which creates a generator.


