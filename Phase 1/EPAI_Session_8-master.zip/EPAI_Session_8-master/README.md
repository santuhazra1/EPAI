## Session 8

#### In this assignment we are going to explore closer in depth. We have 4 problems to solve as below and for that we have written 4 different functions as below:

#### dockstring_check:

##### In this closer function we are going to pass a function and our function will check if docstring is present and if so then if its character is grater than 50 then it will return True else False. We just have to initialize it for the first time.



#### fibonacci_series:

##### In this closer function every time we run our function it will print the next fibonacci number in the series after initializing it for the first time.



#### counter_global:

##### In this closer function we are going to check how many times of add / mul / div function was called and we will store it in a global dictionary. We have to initialize an empty dictionary in the beginning.



#### counter_multiple_user:

##### This closer function is similar to the above function but here we can pass different dictionaries to the function and we can keep track of how many times add / mul / div was called for different user at the same time.



