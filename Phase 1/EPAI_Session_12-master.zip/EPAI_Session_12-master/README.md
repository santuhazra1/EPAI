## Calculator package

#### Here we have implemented a calculate package with functions sin, cos, tan, tanh, relu, sigmoid, softmax, log, e and their corresponding derivatives.

#### Here we have created different modules for all different functions and a separate module named derivative where we can call only derivatives of the above functions. 

#### Now, as an example if we do import calculator we will be able to only access sin, cos, tan, tanh, relu, sigmoid, softmax, log, e functions. And if we do from calculator import derivatives then we can access only derivatives and not the originals functions.