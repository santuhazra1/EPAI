from .Sin import dsin
from .Cos import dcos
from .Tan import dtan
from .Tanh import dtanh
from .Sigmoid import dsigmoid
from .ReLU import drelu
from .Log import dlog
from .Exp import de
