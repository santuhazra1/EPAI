## Ploygon

#### In this assignment we have implemented two different class in two different module.

#### Ploygon:

##### In this class we have implemented such way that it will take input as #edges and side length and it will output #edges, #vertices, interior angle, edge length, apothem, area and perimeter. Also, we have implemented __eq__ method such way that is no of edges and side length is same for two Ploygon '==' will return True else False. Similarly, __gt__  method such way that it will return True with garter no of vertices.

#### Ploygons:

##### In this class we have created getitem method. Also, we have implemented a property max_efficiency_polygon which will return maximum effiency polygon. 