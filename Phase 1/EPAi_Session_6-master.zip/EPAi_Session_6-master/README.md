# Session 6

#### In this Assignment we have explored first class functions i.e lambda, map, zip

#### We are going to create a poker game which will take 3 inputs as count of cards, Player A cards set and Player B card set and it will return the winner player.



#### deck_with_lambda_map_zip:

##### In this deck_with_lambda_map_zip function we have created one single line expression to create a deck of 52 cards with the help of lambda, zip and map function.



#### deck_without_lambda_map_zip:

##### In this deck_with_lambda_map_zip function we have created one single line expression to create a deck of 52 cards without using lambda, zip and map function.



#### poker:

##### In this function we are going to give input one card count value which is going to be a value between 3 and 5 and Player A card set and Player B card set. And based on rules of poker it will decide who own and will return a string about who own Player A or B
