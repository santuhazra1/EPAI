## Session 10

#### In this assignment we are going to implement namedtuple for different use case in the below functions:

#### namedtuple_profile:

##### This function takes n as an integer and creates n no of profiles in a tuple of namedtuples and from there it returns blood group with max frequency, mean location of all profiles address. Also, I tried to create namedtuple of namedtuples but I observed that it can take only 255 arguments.



#### dict_profile:

##### This function takes n as an integer and creates n no of profiles in a list of dictionaries and from there it returns blood group with max frequency, mean location of all profiles address, maximum age and average age.



#### perf_chek:

##### This function checks the performance of the above two functions and returns timediff between two.



#### create_company_tuple:

##### This function returns a namedtuple object of fake  company name, symbol, company stock market open, high and close price. We have created open value as random no between 10 and 4000. High value should range from 90% to 110% of open value and close value should range from 90% to 100% of high value.