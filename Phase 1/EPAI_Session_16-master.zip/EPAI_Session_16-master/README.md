## Context Manager

#### In this assignment we have implemented a multiple iterator and combined them into a single iterator. Also we have implemented a context manager which can read a csv file with the help of csv and readr library.