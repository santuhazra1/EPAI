from PIL import Image
import os
import glob
import argparse
import warnings
warnings.filterwarnings("ignore")

def get_path_list(folder_path):
    files_grabbed = glob.glob(folder_path + '*.png')
    return files_grabbed

def convert_jpg_to_png(filepath):
    if filepath[-4:] == ".png":
        file_name = filepath[:-4]
    img = Image.open(filepath)
    img = img.convert('RGB')
    img.save(file_name + ".jpg")
    os.remove(filepath)

def convert(folderpath):
    list(map(lambda path: convert_jpg_to_png(path),get_path_list(folderpath)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('-f', '--folderpath', 
                        type=str,
                        help='Folder path of the image directory.')
    args = parser.parse_args()
    convert(args.folderpath)