# test1.py

print('running test1.py...')

def print_values():
	print('k1', '10')
	print('k2', '40')
	print('k3', 'cheese')
	print('k4', 'bread')
