print('running modulem.py...')
x = 'python'