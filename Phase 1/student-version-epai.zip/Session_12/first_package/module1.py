print('Executing module1...')

value = 'module1 value'

import pack1.pack1_1.module1_1a
import pack1.pack1_1.module1_1b
import pack1.module1a

import pack1.pack1_1

import pack1 
