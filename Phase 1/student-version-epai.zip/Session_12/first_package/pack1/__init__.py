print('Executing pack1')
values = 'pack1 values'

import pack1.pack1_1